/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import login.TelaLogin;
import principal.TelaPrincipal;

/**
 *
 * @author Franciele Alves Barbosa e Rogério Costa Negro Rocha
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        //TelaLogin meuLogin = new TelaLogin();
        //meuLogin.setVisible(true);

        TelaPrincipal telaPrincipal= new TelaPrincipal();
        telaPrincipal.setVisible(true);
    }
}
